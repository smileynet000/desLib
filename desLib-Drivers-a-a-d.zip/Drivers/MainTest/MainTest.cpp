/*
 Program:

 File:

 Description:

 Author: Dennis Earl Smiley

 Enviroment: Dev-C++ 5.5.3

 Notes:

 Revisons:
*/
// Includes go here...
#include "../../Source/desLib.hpp"


// Classes go here...


// Global variables go here...


// Function prototypes go here...


// Functions go here...
int Main(Array<String> args)
{
 io << (char *)"Hello World!\n";
 
 
 return 0;
}
